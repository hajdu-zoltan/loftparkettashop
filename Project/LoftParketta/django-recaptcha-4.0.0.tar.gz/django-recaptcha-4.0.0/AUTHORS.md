# Authors

## Current Maintainers

- [Andrew Chen Wang](https://github.com/Andrew-Chen-Wang)
- [Storm Heg](https://github.com/Stormheg)

## Praekelt Consulting

- Shaun Sephton
- Peter Pistorius
- Hedley Roos
- Altus Barry
- Cilliers Blignaut

## bTaylor Design

- [Brandon Taylor](http://btaylordesign.com/)

## Other

- Brooks Travis
- [Denis Mishchishin](https://github.com/denz)
- [Joshua Peper](https://github.com/zout)
- [Rodrigo Primo](https://github.com/rodrigoprimo)
- [snnwolf](https://github.com/snnwolf)
- [Adriano Orioli](https://github.com/Aorioli)
- [cdvv7788](https://github.com/cdvv7788)
- [Daniel Gatis Carrazzoni](https://github.com/danielgatis)
- [pbf](https://github.com/pbf)
- [Alexey Subbotin](https://github.com/dotsbb)
- [Sean Stewart](https://github.com/mindcruzer)
- [Rob Charlwood](https://github.com/robcharlwood)
- [Ruslan Kovtun](https://github.com/koutoftimer)
